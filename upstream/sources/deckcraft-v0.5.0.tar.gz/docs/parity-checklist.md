# PowerPoint feature checklist

> **Generated:** 2026-10-10 (summary by `cargo xtask parity`; rows re-scored 2026-10-10 against PowerPoint for Mac 16.113.4) · **Target:** Microsoft PowerPoint for Mac 16.113 (Microsoft 365)

The summary between `<!-- SUMMARY -->
**Weighted breadth parity: 79%** over 191 features.

| Priority | Features | Done | Partial | Missing | Parity |
|---|---|---|---|---|---|
| P0 | 72 | 60 | 12 | 0 | 92% |
| P1 | 65 | 38 | 21 | 6 | 75% |
| P2 | 54 | 13 | 13 | 28 | 36% |

| Area | Parity |
|---|---|
| Application shell | 71% |
| Files | 71% |
| Slides | 90% |
| Views | 90% |
| Masters & themes | 85% |
| Shapes | 86% |
| Format | 81% |
| Arrange | 100% |
| Text | 80% |
| Tables | 89% |
| Charts | 65% |
| SmartArt | 33% |
| Pictures | 48% |
| Media | 67% |
| Transitions | 92% |
| Animations | 79% |
| Slide show | 66% |
| Review | 60% |
| Draw | 33% |
| Undo & clipboard | 88% |
| Automation (✱) | 100% |
| Platforms (✱) | 67% |

Open P0 items: Start screen (new, templates/themes, recent), Contextual tabs (Shape Format, Picture Format, Table Design/Layout, Chart Design), Export to PDF (slides, notes pages, handouts; text layer, links, bookmarks; vector artwork pending), Format Shape pane, Font, size, bold, italic, underline, strikethrough (only Regular/Bold/Italic faces, #69), Edit chart data, Crop (and crop to shape, aspect ratio), Paste image from clipboard (fails on Windows and Linux, #53), Audio/video playback in the show (WMA/WMV not decodable yet), Animation pane (reorder, timing), Presenter view (notes, next slide, timer), macOS, Windows, Linux builds.

## Rows

| Area | Feature | Priority | Status |
|---|---|---|---|
| Application shell | Start screen (new, templates/themes, recent) | P0 | P |
| Application shell | Ribbon with Home/Insert/Draw/Design/Transitions/Animations/Slide Show/Review/View tabs | P0 | D |
| Application shell | Contextual tabs (Shape Format, Picture Format, Table Design/Layout, Chart Design) | P0 | P |
| Application shell | Quick Access toolbar / title bar commands | P1 | P |
| Application shell | Native menu bar (macOS) with every command | P1 | M |
| Application shell | Command palette / Tell me search | P1 | D |
| Application shell | Keyboard shortcuts for every common command | P0 | D |
| Application shell | Status bar (slide counter, notes, comments, views, zoom) | P0 | D |
| Application shell | Light and dark appearance | P1 | D |
| Application shell | Multiple open presentations | P1 | P |
| Application shell | Preferences (autosave, units, defaults) | P2 | P |
| Files | New blank presentation | P0 | D |
| Files | Native file format (open/save) | P0 | D |
| Files | Open PowerPoint .pptx | P0 | D |
| Files | Save as PowerPoint .pptx | P0 | D |
| Files | Open/save .potx/.ppsx/.pptm variants (.potx/.ppsx open; saved with the .pptx content type; no .pptm) | P2 | P |
| Files | Legacy .ppt (binary) import | P2 | M |
| Files | Save as template | P1 | D |
| Files | Autosave and crash recovery | P0 | D |
| Files | Document properties | P2 | D |
| Files | Export to PDF (slides, notes pages, handouts; text layer, links, bookmarks; vector artwork pending) | P0 | P |
| Files | Export slides as PNG/JPEG | P0 | D |
| Files | Export outline / RTF | P2 | P |
| Files | Export video (MP4) / animated GIF | P2 | M |
| Files | Print (slides, handouts, notes, outline) | P1 | M |
| Files | Password protection | P2 | M |
| Files | Reuse slides from another file | P1 | M |
| Files | Drag and drop files onto the window | P1 | D |
| Files | OpenDocument .odp open/save | P2 | M |
| Slides | New slide by layout | P0 | D |
| Slides | Duplicate, delete, hide slides | P0 | D |
| Slides | Reorder slides (thumbnails, sorter) | P0 | D |
| Slides | Sections (add, rename, remove, move, collapse) | P1 | D |
| Slides | Slide layouts (11 standard) | P0 | D |
| Slides | Reset slide | P1 | D |
| Slides | Slides from outline | P2 | D |
| Slides | Copy/paste slides between decks | P1 | P |
| Slides | Zoom (summary, section and slide zoom) | P2 | M |
| Views | Normal view (thumbnails, slide, notes) | P0 | D |
| Views | Outline view | P1 | D |
| Views | Slide Sorter | P0 | D |
| Views | Notes Page | P1 | D |
| Views | Reading View | P1 | D |
| Views | Zoom, fit to window | P0 | D |
| Views | Rulers, gridlines, guides | P1 | P |
| Views | Smart guides | P1 | D |
| Views | Grayscale / black and white view | P2 | D |
| Views | New window / arrange windows | P2 | M |
| Masters & themes | Slide Master view (edit master and layouts) | P0 | D |
| Masters & themes | Insert/rename/delete layouts, insert placeholders | P1 | D |
| Masters & themes | Handout and Notes masters | P2 | M |
| Masters & themes | Built-in themes (original designs) | P0 | D |
| Masters & themes | Theme variants | P1 | P |
| Masters & themes | Colour schemes (built-in and custom) | P0 | D |
| Masters & themes | Font schemes (built-in and custom) | P0 | D |
| Masters & themes | Effect schemes / background styles | P2 | P |
| Masters & themes | Format background (solid, gradient, picture, pattern) | P0 | D |
| Masters & themes | Hide background graphics | P1 | D |
| Masters & themes | Slide size (16:9, 4:3, presets, custom) | P0 | D |
| Masters & themes | Header & footer (date, slide number, footer) | P1 | D |
| Masters & themes | Browse themes from .pptx/.thmx | P2 | M |
| Masters & themes | Designer layout suggestions (offline) | P2 | M |
| Shapes | Preset shapes (lines, rectangles, basic, arrows, equation, flowchart, stars, callouts) | P0 | D |
| Shapes | Action buttons | P2 | D |
| Shapes | Adjustment handles | P0 | D |
| Shapes | Connectors (straight, elbow, curved) | P0 | D |
| Shapes | Connector glue to connection sites | P1 | D |
| Shapes | Freeform, curve and scribble tools | P1 | D |
| Shapes | Edit points | P1 | M |
| Shapes | Merge shapes (union, combine, fragment, intersect, subtract) | P1 | D |
| Shapes | Change shape | P1 | D |
| Shapes | Text boxes | P0 | D |
| Shapes | WordArt | P1 | P |
| Shapes | Text warp transforms | P2 | M |
| Shapes | Shape quick styles | P1 | D |
| Shapes | Set as default shape | P2 | D |
| Format | Solid fill and transparency | P0 | D |
| Format | Gradient fill (linear, radial, rectangular, path) | P0 | D |
| Format | Picture and texture fill | P1 | P |
| Format | Pattern fill | P2 | P |
| Format | Line colour, width, dash, compound, cap, join | P0 | D |
| Format | Arrowheads | P0 | D |
| Format | Shadow (outer, inner, presets) | P1 | D |
| Format | Reflection, glow, soft edges | P2 | P |
| Format | Bevel and 3-D rotation | P2 | M |
| Format | Format Painter | P1 | D |
| Format | Format Shape pane | P0 | P |
| Arrange | Size and position (exact), lock aspect ratio | P0 | D |
| Arrange | Rotate and flip | P0 | D |
| Arrange | Bring forward / send backward / to front / to back | P0 | D |
| Arrange | Align and distribute | P0 | D |
| Arrange | Group, ungroup, regroup | P0 | D |
| Arrange | Selection pane (names, visibility, order) | P1 | D |
| Arrange | Nudge, duplicate with repeat offset | P1 | D |
| Arrange | Lock shapes | P2 | D |
| Arrange | Alt text | P1 | D |
| Text | In-place text editing (caret, selection, mouse, keyboard) | P0 | D |
| Text | Font, size, bold, italic, underline, strikethrough (only Regular/Bold/Italic faces, #69) | P0 | P |
| Text | Font colour, highlight | P0 | D |
| Text | Superscript, subscript, caps, character spacing | P1 | D |
| Text | Change case, grow/shrink font, clear formatting | P1 | D |
| Text | Text outline and text effects | P2 | P |
| Text | Paragraph alignment, indents, spacing, line spacing | P0 | D |
| Text | Bullets and numbering | P0 | D |
| Text | Picture bullets, custom bullet symbols | P2 | P |
| Text | List levels (Tab / Shift+Tab) | P0 | D |
| Text | Tab stops | P2 | P |
| Text | Columns | P2 | D |
| Text | Vertical anchor, margins, wrap | P0 | D |
| Text | Autofit (shrink on overflow, resize shape) | P0 | D |
| Text | Text direction (rotated, stacked) | P1 | D |
| Text | Find and replace, replace fonts | P1 | P |
| Text | Spelling check | P1 | P |
| Text | Thesaurus | P2 | M |
| Text | AutoCorrect and smart quotes | P2 | M |
| Text | Symbols and emoji | P1 | D |
| Text | Equations | P2 | M |
| Text | Hyperlinks (URL, slide, email) | P1 | D |
| Text | Date/time and slide number fields | P1 | D |
| Text | Right-to-left and complex scripts | P1 | P |
| Text | East Asian text (CJK fonts, line breaking) | P1 | P |
| Tables | Insert table (grid picker, dialog) | P0 | D |
| Tables | Draw table | P2 | M |
| Tables | Table styles and style options | P0 | D |
| Tables | Insert/delete rows and columns | P0 | D |
| Tables | Merge and split cells | P1 | D |
| Tables | Distribute rows/columns, sizes | P1 | D |
| Tables | Cell fill, borders, margins, alignment | P1 | P |
| Tables | Keyboard navigation between cells | P0 | D |
| Charts | Insert chart (column, bar, line, area, pie, doughnut, scatter) | P0 | D |
| Charts | Other chart types (radar, stock, combo, waterfall, funnel, treemap, sunburst, histogram, box) | P2 | P |
| Charts | Edit chart data | P0 | P |
| Charts | Chart elements (title, legend, labels, axes, gridlines) | P1 | P |
| Charts | Chart styles and colours | P2 | P |
| SmartArt | Insert SmartArt (lists, processes, cycles, hierarchy) | P1 | P |
| SmartArt | Text pane and layout switching | P2 | M |
| Pictures | Insert picture (PNG, JPEG, GIF, WebP, BMP, TIFF) | P0 | D |
| Pictures | SVG pictures | P1 | M |
| Pictures | Crop (and crop to shape, aspect ratio) | P0 | P |
| Pictures | Corrections, colour, transparency | P1 | P |
| Pictures | Artistic effects | P2 | M |
| Pictures | Remove background | P2 | M |
| Pictures | Picture styles and borders | P1 | P |
| Pictures | Change / reset picture | P1 | D |
| Pictures | Compress pictures | P2 | M |
| Pictures | Paste image from clipboard (fails on Windows and Linux, #53) | P0 | P |
| Pictures | Insert screenshot | P2 | M |
| Media | Insert audio (any common format) | P0 | D |
| Media | Insert video | P1 | D |
| Media | Audio/video playback in the show (WMA/WMV not decodable yet) | P0 | P |
| Media | Trim, fade in/out, volume, loop, play across slides | P2 | D |
| Media | Record audio / screen recording | P2 | M |
| Media | Icons, 3-D models, stock content | P2 | M |
| Media | Embedded objects (OLE): insert; foreign objects kept on round trip | P2 | P |
| Transitions | Transition gallery (fade, push, wipe, split, cover, uncover, zoom, morph…) | P0 | D |
| Transitions | Effect options and duration | P0 | D |
| Transitions | Advance on click / after time, apply to all | P0 | D |
| Transitions | Transition sounds | P2 | M |
| Transitions | Morph | P1 | D |
| Animations | Entrance, emphasis, exit effects | P0 | D |
| Animations | Motion paths | P1 | P |
| Animations | Effect options, start (on click/with/after), duration, delay | P0 | D |
| Animations | Animation pane (reorder, timing) | P0 | P |
| Animations | By-paragraph text builds | P1 | D |
| Animations | Triggers | P2 | D |
| Animations | Animation Painter | P2 | D |
| Animations | Preview in editor | P1 | P |
| Slide show | Full-screen show from start / current | P0 | D |
| Slide show | Navigation (keys, click, go to slide, blank screen) | P0 | D |
| Slide show | Presenter view (notes, next slide, timer) | P0 | P |
| Slide show | Pen and highlighter ink during the show | P1 | P |
| Slide show | Laser pointer | P2 | M |
| Slide show | Rehearse timings | P2 | D |
| Slide show | Custom shows | P2 | D |
| Slide show | Set up show (loop, kiosk, without animation) | P1 | D |
| Slide show | Record slide show (narration) | P2 | M |
| Slide show | Multi-monitor presenting | P1 | M |
| Review | Comments (add, reply, resolve, delete) | P1 | D |
| Review | Accessibility checker | P2 | D |
| Review | Compare presentations | P2 | M |
| Review | Track changes / version history | P2 | M |
| Draw | Ink pens, highlighter, eraser | P1 | P |
| Draw | Ink to shape / text | P2 | M |
| Undo & clipboard | Unlimited undo/redo | P0 | D |
| Undo & clipboard | Cut, copy, paste shapes and slides | P0 | D |
| Undo & clipboard | Paste special (keep formatting, picture, text only) | P1 | P |
| Automation (✱) | Every command scriptable (CLI, control channel, MCP) | P0 | D |
| Automation (✱) | Headless rendering and conversion | P0 | D |
| Platforms (✱) | macOS, Windows, Linux builds | P0 | P |
| Platforms (✱) | Web (WASM) build | P1 | D |
| Platforms (✱) | BSD build | P2 | P |
